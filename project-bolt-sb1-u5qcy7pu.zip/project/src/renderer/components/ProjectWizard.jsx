@@ .. @@
   const [currentStep, setCurrentStep] = useState(0);
   const [projectData, setProjectData] = useState({
     name: '',
   }
   )
-    version: '1.20.1',
+    version: '1.20.4',
     modLoader: 'forge',
     features: [],
     author: '',
@@ .. @@
         <div className="mb-6">
           <label className="block text-sm font-medium text-gray-700 mb-2">
             Minecraft Version
           </label>
           <select
             value={projectData.version}
             onChange={(e) => setProjectData({...projectData, version: e.target.value})}
             className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
           >
-            <option value="1.20.1">1.20.1</option>
+            <option value="1.20.4">1.20.4 (Latest)</option>
+            <option value="1.20.1">1.20.1</option>
             <option value="1.19.4">1.19.4</option>
             <option value="1.18.2">1.18.2</option>
           </select>